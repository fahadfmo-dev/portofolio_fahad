<?php
require 'fonctions.php';
$bdd = getBdd();
$message = '';

if (isset($_POST['matricule']) && trim($_POST['matricule']) !== '') {
    $cadre = isset($_POST['cadre']) ? 'o' : 'n';
    $stmt = $bdd->prepare('INSERT INTO employe VALUES (:mat, :nom, :prenom, :cadre, :serv)');
    $stmt->execute([
        ':mat'    => trim($_POST['matricule']),
        ':nom'    => trim($_POST['nom']),
        ':prenom' => trim($_POST['prenom']),
        ':cadre'  => $cadre,
        ':serv'   => $_POST['service']
    ]);
    $message = "L'ajout a réussi !";
}

$reqServices = $bdd->query('SELECT CodeServ, DesiServ FROM service ORDER BY DesiServ');
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Ajout employé</title></head>
<body>
    <h1>Ajout d'un employé</h1>
    <form method="post">
        <label>Matricule : <input type="text" name="matricule" maxlength="4"></label><br><br>
        <label>Nom : <input type="text" name="nom" maxlength="25"></label><br><br>
        <label>Prénom : <input type="text" name="prenom" maxlength="20"></label><br><br>
        <label>Cadre ? <input type="checkbox" name="cadre" value="o"></label><br><br>
        <label>Service :
            <select name="service">
                <?php while ($s = $reqServices->fetch()) { ?>
                <option value="<?php echo escape($s['CodeServ']); ?>">
                    <?php echo escape($s['DesiServ']); ?>
                </option>
                <?php } ?>
            </select>
        </label><br><br>
        <input type="submit" value="Ajouter l'employé">
    </form>
    <?php if ($message) echo '<p>' . escape($message) . '</p>'; ?>
</body>
</html>