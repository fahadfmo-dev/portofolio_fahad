<?php
$a = 2;
$a = $a - 1;
$a++;

$b = 8;
$b += 2;

$c = $a + $b * $b;
$d = $a * $b + $b;
$e = $a * ($b + $b);
$f = $a * $b / $a;
$g = $b / $a * $a;
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Mystère</title>
</head>
<body>
    <p>$a = <?php echo $a; ?></p>
    <p>$b = <?php echo $b; ?></p>
    <p>$c = <?php echo $c; ?></p>
    <p>$d = <?php echo $d; ?></p>
    <p>$e = <?php echo $e; ?></p>
    <p>$f = <?php echo $f; ?></p>
    <p>$g = <?php echo $g; ?></p>
</body>
</html>