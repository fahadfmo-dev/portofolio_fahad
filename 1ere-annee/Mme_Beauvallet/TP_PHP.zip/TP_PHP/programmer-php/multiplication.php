<?php
    $chiffre = 7;
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Table de multiplication</title>
</head>
<body>
    <h1>La table de <?php echo $chiffre; ?></h1>
    <?php
    for ($i = 1; $i <= 10; $i++) {
        echo $chiffre . ' * ' . $i . ' = ' . ($chiffre * $i) . '<br>';
    }
    ?>
</body>
</html>