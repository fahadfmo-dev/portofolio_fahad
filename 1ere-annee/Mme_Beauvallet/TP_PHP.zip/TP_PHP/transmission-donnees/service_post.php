<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Service sélectionné</title>
</head>
<body>
    <?php
        $code = htmlspecialchars($_POST['service']);
        echo "<p>Le code du service choisi est $code</p>";
    ?>
</body>
</html>