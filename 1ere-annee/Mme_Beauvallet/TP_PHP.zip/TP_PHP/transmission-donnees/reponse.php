<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Réponse</title>
</head>
<body>
    <?php
        $prenom   = htmlspecialchars($_POST['prenom']);
        $familier = isset($_POST['familier']);
        $civilite = htmlspecialchars($_POST['civilite']);

        $salutation = $familier ? 'Salut' : 'Bonjour';
        $formule    = strtolower($civilite);

        echo "<p>$salutation $formule $prenom !</p>";
    ?>
</body>
</html>