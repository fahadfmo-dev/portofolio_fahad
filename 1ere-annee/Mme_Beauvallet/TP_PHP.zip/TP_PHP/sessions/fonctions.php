<?php
function getBdd() {
    try {
        $pdo = new PDO(
            'mysql:host=localhost;dbname=monsite;charset=utf8',
            'monsite_util',
            'secret',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return $pdo;
    } catch (PDOException $e) {
        die('Erreur de connexion : ' . $e->getMessage());
    }
}
?>