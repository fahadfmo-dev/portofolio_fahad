<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Bonjour</title>
</head>
<body>
    <form method="post" action="reponse.php">
        <label>Entrez votre prénom :</label>
        <input type="text" name="prenom" required>
        <br><br>

        <label>Cochez pour un bonjour plus familier :</label>
        <input type="checkbox" name="familier" value="oui">
        <br><br>

        <input type="radio" name="civilite" value="Mademoiselle"> Mademoiselle<br>
        <input type="radio" name="civilite" value="Madame"> Madame<br>
        <input type="radio" name="civilite" value="Monsieur" checked> Monsieur<br>
        <br>

        <input type="submit" value="Dire bonjour">
    </form>
</body>
</html>