<?php
    $prenom = "Fahad";
    $classe = "BTS SIO";
    $langages = ["HTML", "CSS", "PHP", "JavaScript", "Python"];

    $nbLangages = count($langages);

    if ($nbLangages < 3) {
        $experience = "débutant";
    } elseif ($nbLangages <= 4) {
        $experience = "débrouillé";
    } else {
        $experience = "aguerri";
    }

    $titre = "La page de " . $prenom;
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php echo $titre; ?></title>
</head>
<body>
    <h1>Ma présentation</h1>
    <p>Bonjour, je m'appelle <?php echo $prenom; ?> et je suis en <?php echo $classe; ?>.</p>
    <p>Je suis un programmeur <?php echo $experience; ?>. 
       Je connais <?php echo $nbLangages; ?> langages de programmation :</p>
    <ul>
        <?php
        foreach ($langages as $langage) {
            echo '<li>' . $langage . '</li>';
        }
        ?>
    </ul>
</body>
</html>