<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Détails sur un employé</title>
</head>
<body>
    <h1>Détails sur un employé</h1>
    <?php
        $id = $_GET['id'];
        echo "<p>Son identifiant est " . $id . "</p>";
    ?>
</body>
</html>