<?php
require 'fonctions.php';
$bdd = getBdd();
$message = '';

if (isset($_POST['code']) && trim($_POST['code']) !== '') {
    $stmt = $bdd->prepare('INSERT INTO service (CodeServ, DesiServ) VALUES (:code, :desig)');
    $stmt->execute([':code' => trim($_POST['code']), ':desig' => trim($_POST['desig'])]);
    $message = "L'ajout a réussi !";
}

$req = $bdd->query('SELECT CodeServ, DesiServ FROM service ORDER BY CodeServ');
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Ajout service</title></head>
<body>
    <h1>Liste des services</h1>
    <table border="1">
        <tr><th>Code</th><th>Désignation</th></tr>
        <?php while ($s = $req->fetch()) { ?>
        <tr>
            <td><?php echo escape($s['CodeServ']); ?></td>
            <td><?php echo escape($s['DesiServ']); ?></td>
        </tr>
        <?php } ?>
    </table>

    <h1>Ajout d'un service</h1>
    <form method="post">
        <label>Code : <input type="text" name="code" maxlength="3"></label><br><br>
        <label>Désignation : <input type="text" name="desig" maxlength="30"></label><br><br>
        <input type="submit" value="Ajouter le service">
    </form>
    <?php if ($message) echo '<p>' . escape($message) . '</p>'; ?>
</body>
</html>