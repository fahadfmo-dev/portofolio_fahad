<?php
session_start();
$erreur = '';

if (isset($_POST['login']) && isset($_POST['mdp'])) {
    require 'fonctions.php';
    $bdd = getBdd();

    // Étape 1 : vérifier si le login existe
    $req1 = $bdd->prepare('SELECT * FROM utilis WHERE LoginUtil=?');
    $req1->execute([$_POST['login']]);
    $userLogin = $req1->fetch();

    if (!$userLogin) {
        $erreur = 'Login inconnu. Vérifiez votre identifiant.';
    } else {
        // Étape 2 : vérifier le mot de passe
        $req2 = $bdd->prepare('SELECT * FROM utilis WHERE LoginUtil=? AND PassUtil=?');
        $req2->execute([$_POST['login'], $_POST['mdp']]);
        $userOK = $req2->fetch();

        if ($userOK) {
            $_SESSION['login']  = $userOK['LoginUtil'];
            $_SESSION['nom']    = $userOK['NomUtil'];
            $_SESSION['prenom'] = $userOK['PrenomUtil'];
            header('Location: index.php');
            exit;
        } else {
            $erreur = 'Mot de passe incorrect.';
        }
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Résultat de l'authentification</title>
</head>
<body>
    <h1>Résultat de l'authentification</h1>
    <?php if ($erreur != '') { ?>
        <p style="color:red;"><?php echo $erreur; ?></p>
        <a href="login.php">Nouvel essai</a>
    <?php } ?>
</body>
</html>