<?php
require 'fonctions.php';
$bdd = getBdd();
$req = $bdd->query('SELECT Matricule, NomEmpl, PrenomEmpl FROM employe ORDER BY NomEmpl');
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Tableau des employés</title></head>
<body>
    <h1>Tableau des employés</h1>
    <table border="1">
        <tr><th>Matricule</th><th>Nom</th><th>Prénom</th></tr>
        <?php
        $total = 0;
        while ($e = $req->fetch()) {
            echo '<tr>';
            echo '<td>' . escape($e['Matricule']) . '</td>';
            echo '<td>' . escape($e['NomEmpl']) . '</td>';
            echo '<td>' . escape($e['PrenomEmpl']) . '</td>';
            echo '</tr>';
            $total++;
        }
        ?>
    </table>
    <p>Total : <?php echo $total; ?> employé(s)</p>
</body>
</html>