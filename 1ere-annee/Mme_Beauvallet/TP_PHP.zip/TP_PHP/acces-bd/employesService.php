<?php
require 'fonctions.php';
$bdd = getBdd();
$codeService = $_POST['service'];

$req = $bdd->prepare('
    SELECT e.Matricule, e.NomEmpl, e.PrenomEmpl, s.DesiServ
    FROM employe e
    JOIN service s ON e.ServEmpl = s.CodeServ
    WHERE e.ServEmpl = :service
    ORDER BY e.NomEmpl
');
$req->execute([':service' => $codeService]);

$reqServ = $bdd->prepare('SELECT DesiServ FROM service WHERE CodeServ = :code');
$reqServ->execute([':code' => $codeService]);
$nomService = $reqServ->fetchColumn();
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Employés du service</title></head>
<body>
    <h1>Liste des employés du service <?php echo escape($nomService); ?></h1>
    <table border="1">
        <tr><th>Matricule</th><th>Nom</th><th>Prénom</th></tr>
        <?php while ($e = $req->fetch()) { ?>
        <tr>
            <td><?php echo escape($e['Matricule']); ?></td>
            <td><?php echo escape($e['NomEmpl']); ?></td>
            <td><?php echo escape($e['PrenomEmpl']); ?></td>
        </tr>
        <?php } ?>
    </table>
    <br><a href="service.php">← Retour</a>
</body>
</html>