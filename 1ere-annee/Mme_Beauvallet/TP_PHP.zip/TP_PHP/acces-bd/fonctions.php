<?php
function getBdd() {
    try {
        $bdd = new PDO(
            'mysql:host=localhost;dbname=personnel;charset=utf8',
            'personnel_util',
            'secret'
        );
        $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $bdd;
    } catch (PDOException $e) {
        die('Erreur : ' . $e->getMessage());
    }
}

function escape($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}
?>