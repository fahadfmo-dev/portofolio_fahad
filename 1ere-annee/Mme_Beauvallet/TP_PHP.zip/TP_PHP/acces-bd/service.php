<?php
require 'fonctions.php';
$bdd = getBdd();
$req = $bdd->query('SELECT CodeServ, DesiServ FROM service ORDER BY DesiServ');
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Sélection du service</title></head>
<body>
    <h1>Choix d'un service</h1>
    <form method="post" action="employesService.php">
        <label>Service :
            <select name="service">
                <?php while ($s = $req->fetch()) { ?>
                <option value="<?php echo escape($s['CodeServ']); ?>">
                    <?php echo escape($s['DesiServ']); ?>
                </option>
                <?php } ?>
            </select>
        </label><br><br>
        <input type="submit" value="Afficher les employés">
    </form>
</body>
</html>