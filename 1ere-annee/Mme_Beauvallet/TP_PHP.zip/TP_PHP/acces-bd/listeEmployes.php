<?php
require 'fonctions.php';
$bdd = getBdd();
$req = $bdd->query('SELECT NomEmpl, PrenomEmpl FROM employe ORDER BY NomEmpl');
?>
<!DOCTYPE html>
<html lang="fr">
<head><meta charset="UTF-8"><title>Liste des employés</title></head>
<body>
    <h1>Liste des employés</h1>
    <ul>
    <?php
    $total = 0;
    while ($e = $req->fetch()) {
        echo '<li>' . escape($e['NomEmpl']) . ' ' . escape($e['PrenomEmpl']) . '</li>';
        $total++;
    }
    ?>
    </ul>
    <p>Total : <?php echo $total; ?> employé(s)</p>
</body>
</html>