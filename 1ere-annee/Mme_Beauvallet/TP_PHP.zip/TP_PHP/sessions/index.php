<?php
session_start();
if (!isset($_SESSION['login'])) {
    header('Location: login.php');
    exit;
}
?>
<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Accueil</title>
</head>
<body>
    <h1>Bienvenue</h1>
    <p>
        Bonjour <?php echo htmlspecialchars($_SESSION['prenom']); ?>
        <?php echo htmlspecialchars($_SESSION['nom']); ?> !
    </p>
    <a href="logout.php">Se déconnecter</a>
</body>
</html>