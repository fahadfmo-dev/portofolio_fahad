<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Machine à café</title>
</head>
<body>
    <h1>Votre boisson</h1>
    <form method="post" action="">
        <label>Nom :</label>
        <input type="text" name="nom" required>
        <br><br>

        <label>Prénom :</label>
        <input type="text" name="prenom" required>
        <br><br>

        <label>Choisissez votre boisson :</label>
        <select name="boisson">
            <option value="Café">Café</option>
            <option value="Thé">Thé</option>
            <option value="Chocolat">Chocolat</option>
            <option value="Café crème">Café crème</option>
        </select>
        <br><br>

        <input type="radio" name="sucre" value="Oui" checked> Sucre<br>
        <input type="radio" name="sucre" value="Non"> Sans sucre<br>
        <br>

        <input type="submit" name="valider" value="Valider">
        <input type="reset" value="Annuler">
    </form>

    <?php
        if (isset($_POST['valider'])) {
            $nom     = htmlspecialchars($_POST['nom']);
            $prenom  = htmlspecialchars($_POST['prenom']);
            $boisson = htmlspecialchars($_POST['boisson']);
            $sucre   = htmlspecialchars($_POST['sucre']);

            echo "<p>Bonjour $prenom $nom</p>";
            echo "<p>Votre choix : $boisson</p>";
            echo "<p>Sucre : $sucre</p>";
        }
    ?>
</body>
</html>