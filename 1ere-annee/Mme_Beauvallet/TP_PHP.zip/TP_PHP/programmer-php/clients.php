<?php
$clients = array(
    array('Nom' => 'Zette',  'Prenom' => 'Annie', 'Ville' => 'Paris'),
    array('Nom' => 'Créyon', 'Prenom' => 'Mina',  'Ville' => 'Lyon'),
    array('Nom' => 'Gator',  'Prenom' => 'Ali',   'Ville' => 'Marseille')
);
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Liste des clients</title>
</head>
<body>
    <h1>Liste des clients</h1>
    <table border="1">
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Ville</th>
        </tr>
        <?php
        foreach ($clients as $client) {
            echo '<tr>';
            echo '<td>' . $client['Nom']    . '</td>';
            echo '<td>' . $client['Prenom'] . '</td>';
            echo '<td>' . $client['Ville']  . '</td>';
            echo '</tr>';
        }
        ?>
    </table>
</body>
</html>