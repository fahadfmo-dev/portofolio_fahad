<?php
$nom = "Fahad";
$age = 20;
$titre = "La page de " . $nom;
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php echo $titre; ?></title>
</head>
<body>
    <h1>Bienvenue !</h1>
    <p>Bonjour, je m'appelle <?php echo $nom; ?> et j'ai <?php echo $age; ?> ans.</p>
</body>
</html>